'use client';

import { useState } from 'react';
import ToolHeader from '@/components/ToolHeader';
import Link from 'next/link';
import '@/styles/tool.css';

export default function HookAnalyzer() {
  const [url, setUrl] = useState('');
  const [results, setResults] = useState<any>(null);
  const [error, setError] = useState('');

  const handleHookAnalyze = async () => {
    setError('');
    setResults(null);

    const videoId = url.split('v=')[1]?.split('&')[0];
    if (!videoId) {
      setError('Invalid YouTube URL');
      return;
    }

    try {
      const res = await fetch(
        `https://www.googleapis.com/youtube/v3/videos?part=statistics,contentDetails&id=${videoId}&key=${process.env.NEXT_PUBLIC_YOUTUBE_API_KEY}`
      );
      const data = await res.json();

      if (!data.items || data.items.length === 0) {
        setError('Video not found or invalid API key');
        return;
      }

      const stats = data.items[0].statistics;

      setResults({
        viewCount: stats.viewCount,
        impressions: 'N/A (requires YouTube Analytics API)',
        ctr: 'N/A (requires YouTube Analytics API)',
        avgViewDuration: 'N/A (requires YouTube Analytics API)',
        retentionData: [100, 90, 80, 60, 50, 30],
        tips: [
          'Hook your audience in the first 5 seconds.',
          'Use an open loop or curiosity-driven question.',
          'Leverage power words and emotional cues.',
          'Complement with an expressive thumbnail.',
        ],
      });
    } catch (err) {
      setError('Error fetching data from YouTube API');
    }
  };

  return (
    <div className="tool-container">
      <ToolHeader
        icon="🎯"
        title="Hook Analyzer"
        description="Analyze your YouTube video's hook effectiveness and retention indicators."
      />

      <div className="tool-input-section">
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://www.youtube.com/watch?v=xyz123"
          className="tool-input"
        />
        <button onClick={handleHookAnalyze} className="tool-button">
          Analyze Hook
        </button>
      </div>

      {error && <p className="tool-error">{error}</p>}

      {results && (
        <div className="tool-results">
          <section>
            <h2 className="tool-section-title">📊 Performance Metrics</h2>
            <ul className="tool-list">
              <li>View Count: {results.viewCount}</li>
              <li>Impressions: {results.impressions}</li>
              <li>Click-Through Rate (CTR): {results.ctr}</li>
              <li>Average View Duration: {results.avgViewDuration}</li>
            </ul>
          </section>

          <section>
            <h2 className="tool-section-title">📈 Simulated Retention Curve</h2>
            <div className="tool-retention-graph">
              {results.retentionData.map((val: number, i: number) => (
                <div
                  key={i}
                  className="tool-retention-bar"
                  style={{ height: `${val}%` }}
                  title={`Minute ${i + 1}: ${val}%`}
                />
              ))}
            </div>
          </section>

          <section>
            <h2 className="tool-section-title">💡 Improvement Tips</h2>
            <ul className="tool-list">
              {results.tips.map((tip: string, i: number) => (
                <li key={i}>{tip}</li>
              ))}
            </ul>
          </section>
        </div>
      )}

      <div className="tool-footer-link">
        <Link href="/dashboard">← Back to Dashboard</Link>
      </div>
    </div>
  );
}
