cd butlr-insights-prototype
git init
git add .
git commit -m "Initial prototype"
gh repo create your-username/butlr-insights-prototype --public --source=. --remote=origin
git push -u origin main

